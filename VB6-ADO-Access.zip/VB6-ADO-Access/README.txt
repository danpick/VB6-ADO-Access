VB6 project that I developed as part of my university PGCE studies.

It is a prototype for a fuller system to help EAL students learn ICT terms.

It is only currently set-up for Arabic, and only fully working for the first question in the system, but easily expandable.

Uses VB6, ADO, Access, Windows Media Player, and strong coding/maintenance principles.